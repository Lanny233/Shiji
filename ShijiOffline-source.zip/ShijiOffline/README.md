# 时记：完全离线的安卓工时打卡 App

这是原生 Android 项目，不是网页套壳。Java + Android 原生控件 + 手机本地 SQLite。
最低支持 Android 8.0（API 26），运行时不需要账户、服务器或网络，也没有声明 INTERNET 权限。

## 功能

- 首页：点击“上班打卡”保存当前时间，再点“下班打卡”保存结束时间并计算本次工时。
- 保存的是时间戳，不靠后台不停运行计时器；锁屏、划掉 App、系统回收进程或重启手机后，已有打卡仍在数据库中。
- 底部切换“工时日历”：展示每天工时、每周总计和当月总计；点击日期补记、编辑或删除记录。
- 同一天可以有多段打卡。跨午夜按北京时间拆分到对应日期；跨月周仍统计完整的周一至周日。
- 正在进行的工时显示在首页，结束后才加入日/周/月实际工时。
- 周一至周五的**法定节日本日**自动加 8 小时。调休、补休、补班日，以及周末的法定节日，不自动加时。
- 节日实际出勤工时与补时相加。补时可以修改、设为 0 删除，或恢复自动规则。
- 不自动扣除午休：可午休前下班打卡、午休后再上班打卡。
- 内置中国大陆 2026 年节假日数据，支持通过手机文件选择器导入其他年份的 CSV，全程不需要 App 联网。

## 一、最容易的构建方法：Android Studio

1. 从 Android 官方网站安装 Android Studio：https://developer.android.com/studio 。
2. 解压源码 ZIP。将项目放在方便的位置，例如 `D:\AndroidProjects\ShijiOffline`。
3. 启动 Android Studio，选择 **Open**，选中这个项目根目录；根目录里应能看到 `settings.gradle`、`gradlew.bat` 和 `app` 文件夹。不要只打开 `app` 文件夹。
4. 在 **Tools → SDK Manager** 安装：
   - SDK Platforms：Android 15 / API 35（Android SDK Platform 35）。
   - SDK Tools：Android SDK Build-Tools 35.0.0（需要时勾选 Show Package Details）；Android SDK Platform-Tools。
5. 在 **Settings → Build, Execution, Deployment → Build Tools → Gradle**，将 Gradle JDK 设为 **JDK 17**。若列表里没有，可用该界面的 Download JDK 下载 17。项目的固定组合是 AGP 8.9.2 + Gradle 8.11.1 + JDK 17，不必为了这个项目升级插件。
6. 等待 Gradle Sync 完成。**首次构建电脑通常需要联网**，用于下载 Gradle、Android Gradle Plugin、SDK 等构建工具；这与手机 App 离线运行是两回事。
7. 打开 Android Studio 的 **Terminal**，在项目根目录运行：

   Windows PowerShell：
   ```powershell
   .\gradlew.bat :app:assembleDebug
   ```
   macOS / Linux：
   ```bash
   chmod +x gradlew
   ./gradlew :app:assembleDebug
   ```

8. 出现 `BUILD SUCCESSFUL` 后，APK 位于：
   ```text
   app/build/outputs/apk/debug/app-debug.apk
   ```
9. 将 APK 通过 USB 或文件传输复制到安卓手机，在手机文件管理器打开，按手机提示允许该来源安装应用，然后安装。

也可以在 Android Studio 的 Build 菜单查找 **Generate App Bundles / APKs → Generate APKs** 或 **Build APK(s)**；不同版本菜单名称可能略有不同。上面的命令行方法更稳定。

### 手机安装与调试

不想使用 USB 调试时，直接把 APK 复制到手机安装即可。使用 adb 时：

```bash
adb install -r app/build/outputs/apk/debug/app-debug.apk
```

需要先打开手机的开发者选项和 USB 调试。`-r` 是覆盖安装，包名与签名一致时会保留数据。

## 二、构建工具版本

| 项目 | 本工程配置 |
|---|---|
| 语言 | Java 17 源码 |
| Android Gradle Plugin | 8.9.2 |
| Gradle Wrapper | 8.11.1 |
| 构建 JDK | 17 |
| compileSdk / targetSdk | 35 / 35 |
| minSdk | 26（Android 8.0） |
| 运行时第三方依赖 | 无 |
| 数据库 | Android 内置 SQLite |
| 网络权限 | 无 |

官方兼容性表：
https://developer.android.com/build/releases/agp-8-9-0-release-notes

命令行构建官方说明：
https://developer.android.com/build/building-cmdline

本项目包含 Gradle Wrapper 的脚本、JAR 和版本配置。不要把运行时没有第三方依赖误解为第一次编译也不需要下载任何工具。

## 三、这些代码分别做什么？

| 文件 | 作用 |
|---|---|
| `app/src/main/java/cn/shiji/offline/MainActivity.java` | 原生界面、上下班按钮、日历、日期/时间选择器、记录编辑、CSV 导入入口 |
| `app/src/main/java/cn/shiji/offline/WorkDb.java` | 创建 SQLite 表，持久保存打卡，增删改，防止时间重叠和重复进行中的记录 |
| `app/src/main/java/cn/shiji/offline/WorkSession.java` | 一条打卡记录：id、上班时间、下班时间、备注 |
| `app/src/main/java/cn/shiji/offline/TimeMath.java` | 日期边界、跨日拆分、每周周一、工时显示；不依赖 Android，便于单独测试 |
| `app/src/main/java/cn/shiji/offline/HolidayRules.java` | 节假日 CSV 校验和自动补时判断 |
| `app/src/main/assets/holidays-2026.csv` | 随 APK 打包的本地节假日数据 |
| `app/src/main/AndroidManifest.xml` | App 入口、应用名、无网络权限设置 |
| `app/build.gradle` | 安卓构建版本、包名和 SDK 设置 |
| `tests/CoreTest.java` | 核心计算与 CSV 校验的纯 Java 测试 |

调用关系：界面按钮 → 后台单线程执行数据库操作 → 读取最新数据 → 主线程刷新界面。

所有 SQLite 读写都放到 `ExecutorService` 上，避免在 UI 线程做数据库 I/O。打卡记录是真正写入数据库的，不是只留在 Java 变量里。

### 1. 上下班打卡

第一次点击保存 `System.currentTimeMillis()`，下班时间保留 `null`，表示正在工作。

第二次点击写入结束时间，再计算：

```java
long durationMillis = endMillis - startMillis;
double hours = durationMillis / 3_600_000.0;
```

首页每秒刷新只是更新显示；即使 App 进程不存在，上班时间仍在数据库中，重新打开后计算当前时间与上班时间的差即可。

### 2. 跨日拆分

例如 9 月 21 日 23:00 上班、9 月 22 日 02:00 下班：

- 9 月 21 日：1 小时。
- 9 月 22 日：2 小时。
- 本次总工时：3 小时。

用每条记录与某一天的时间区间求交集：

```java
long part = Math.max(0,
    Math.min(sessionEnd, nextDayStart)
    - Math.max(sessionStart, dayStart));
```

`TimeMath.workMillis()` 实现这一逻辑。存储保留毫秒，显示小时四舍五入至两位小数；周/月统计先累加原始毫秒再统一显示，不累加已经四舍五入的数字。

### 3. 节假日补时

```java
boolean isStatutoryDay = holiday != null && holiday.type.equals("LEGAL");
boolean isMondayToFriday = day.getDayOfWeek().getValue() <= 5;
long autoBonus = isStatutoryDay && isMondayToFriday
        ? 8L * 3_600_000
        : 0L;
```

实际实现位于 `HolidayRules.automaticMillis()`。数据库中的手动补时优先于自动结果；“删除补时”保存数值 0，而不是删除覆盖记录，否则自动 8 小时会再次出现。“恢复自动”才删除覆盖记录。

节假日补时按日历日期展示，未来节日也会出现在所在周/月；进行中的打卡不计入已完成工时。

### 4. SQLite 表

- `work_sessions`：打卡起止时间和备注，最多一条进行中的记录。
- `day_adjustments`：某一天手动指定的补时。
- `holidays`：法定节日、调休补休、补班标记。
- `holiday_years`：已经导入节假日表的年份。

数据库存储在 App 私有目录，由 Android 管理；不需要读写整个手机存储的权限。

## 四、增加以后年份的节假日

完全离线的 App 不能自动获取尚未收录或尚未公布的节假日安排，因此要预置或手动导入。

准备 UTF-8 编码 CSV，表头是：

```csv
date,type,name
2026-01-01,LEGAL,元旦
2026-01-02,OFF,元旦调休
2026-01-04,WORK,元旦补班
```

上面只是格式示例。**实际导入必须使用完整年度数据**，不能拿这三行替换全年；因为导入会替换文件中涉及的整个年份。

| type | 含义 | 自动补时 |
|---|---|---|
| LEGAL | 法定节日本日 | 周一至周五加 8 小时 |
| OFF | 调休或补休 | 不自动加 |
| WORK | 补班 | 不自动加，按实际打卡计算 |

在 App 顶部“规则 / 导入”→“导入节假日 CSV”选择手机本地文件。无需网络或重新安装。

规则：每行三个字段；日期 `YYYY-MM-DD`；同一天不能重复；名称不能含英文逗号；无须列出普通周末；文件上限 256 KB/3000 行。导入改变所含年度的节假日表，不改变已有打卡和手动补时。

内置 2026 数据参考：
- 国务院办公厅关于2026年部分节假日安排的通知：https://www.scio.gov.cn/zdgz/jj/202511/t20251110_938367.html
- 全国年节及纪念日放假办法（2024修订）：https://www.scio.gov.cn/live/2025/35455/wjzc/202501/t20250123_883282.html

这是按本 App 指定规则做工时统计，不涉及加班工资倍率计算。

## 五、测试

只有 JDK 17、没有 Android SDK 时，也可以运行计算测试：

Windows：
```powershell
.\tools\test-core.bat
```
macOS / Linux：
```bash
./tools/test-core.sh
```

建议在真机安装后按顺序检查：
1. 开启飞行模式；上班打卡，退出 App，再打开后下班打卡。
2. 补记一个过去日期的 09:00–18:00，确认是 9 小时；改成 09:00–17:00，确认是 8 小时。
3. 补记 23:00 到次日 02:00，查看两天分别计入 1、2 小时。
4. 删除一条记录，确认日/周/月汇总同步变化。
5. 查看 2026-09-25：中秋节默认 +8；2026-10-03 周六不补时；2026-10-05 补休不补时。
6. 将 9 月 25 日补时改为 0，确认变为 0；点“恢复自动”，确认回到 8。
7. 上班后重启手机，再打开 App，确认正在工作状态仍在。

实际完成的验证与构建状态见 `BUILD_STATUS.md`，上面的真机清单不是已经执行过的证明。

## 六、长期使用：构建自己的签名 APK

Debug APK 适合先安装试用。长期使用建议自己生成签名：

1. Android Studio → **Build → Generate Signed App Bundle or APK**。
2. 选择 **APK**，不是 Android App Bundle。
3. 选择 **Create new**，在你自己的电脑创建 `.jks` 密钥库，设置并保存密码和 alias。
4. 选择 `release` 构建并完成签名；按构建提示定位 APK。
5. 保管好密钥库。以后更新使用同一包名、同一签名，并增加 `app/build.gradle` 中的 `versionCode`。

同一包名但不同签名的 APK 不能直接覆盖安装。由这里编译的测试 APK与在你电脑上新生成的 debug/release APK 通常签名不同，因此建议在正式记录之前选定自己的长期签名版本。

**不要为了更新而直接卸载已经有数据的版本：本版没有记录备份/迁移功能，卸载或清除应用数据会删除本地工时。**

## 七、常见构建问题

- `SDK location not found`：用 Android Studio 打开项目并设置 SDK；或者在项目根目录创建 `local.properties`：
  ```properties
  sdk.dir=C:/Users/你的用户名/AppData/Local/Android/Sdk
  ```
  这里是电脑的 SDK 路径；不要照抄别人的路径。
- `JAVA_HOME` 或 JDK 版本错误：Gradle JDK 选 17，命令行用 `java -version` 验证；需要完整 JDK，不只是 JRE。
- 下载依赖失败：先解决电脑到 Google Maven、Maven Central、Gradle 官方下载站的网络连接；不要把手机运行时离线与构建工具下载混为一谈。
- 想在电脑断网时重新编译：必须先成功构建并缓存完整的 SDK、Gradle 和所有插件依赖，然后尝试 `./gradlew --offline :app:assembleDebug`。仅有源码 ZIP 不能保证在一台新电脑上离线构建。
- APK 安装失败：检查 Android 是否至少为 8.0、文件是否完整、是否已有同包名但不同签名版本。

## 限制

- 使用手机系统时钟；主动修改系统日期/时间会影响计时，App 会拒绝结束时间早于开始时间的记录。
- 不跨设备同步；不申请联网权限。
- 不自动获取未来节假日；无数据的年份会提示，可手动补时或导入 CSV。
- 用户编辑的是整段打卡；删除跨日记录会影响它覆盖的每一天。
- 本版不含加班费计算、定位考勤、公司后台或记录备份功能。


## 八、可选：不用 Gradle，直接用 SDK 打包（Linux / macOS）

这是本次交付测试 APK 实际使用的方法。需要 Python 3、Java 17（包含 jdk.compiler）、Android SDK Platform 35 和 Build Tools 35.0.0：

```bash
ANDROID_HOME=/你的/Android/Sdk ./tools/build-sdk.sh
```

输出路径：`build/sdk-debug/shiji-offline-debug.apk`。

脚本依次执行 AAPT2 资源编译、Java 编译、D8 生成 DEX、打包、zipalign 和 apksigner 签名。它会在 `build/sdk-debug/trial-debug.keystore` 创建本地测试密钥；该密钥不是正式发布密钥，也不在交付源码包中。

Windows 用户优先使用前面的 Android Studio / Gradle 方法。

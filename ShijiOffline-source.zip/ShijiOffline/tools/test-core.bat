@echo off
setlocal
cd /d "%~dp0.."
if not exist build\core-test mkdir build\core-test
javac -encoding UTF-8 -d build\core-test app\src\main\java\cn\shiji\offline\WorkSession.java app\src\main\java\cn\shiji\offline\TimeMath.java app\src\main\java\cn\shiji\offline\HolidayRules.java tests\CoreTest.java
if errorlevel 1 exit /b 1
java -cp build\core-test CoreTest

#!/usr/bin/env bash
# Alternative build without Gradle. Requires Android SDK 35/build-tools 35.0.0
# and Java 17 with the jdk.compiler module. This is also the verified build path
# used for the provided trial APK.
set -euo pipefail
cd "$(dirname "$0")/.."
: "${ANDROID_HOME:?Set ANDROID_HOME to your Android SDK directory}"
SDK_TOOLS="$ANDROID_HOME/build-tools/35.0.0"
ANDROID_JAR="$ANDROID_HOME/platforms/android-35/android.jar"
JAVA_EXEC="${JAVA_HOME:+$JAVA_HOME/bin/}java"
KEYTOOL_EXEC="${JAVA_HOME:+$JAVA_HOME/bin/}keytool"
OUT="build/sdk-debug"
mkdir -p "$OUT/classes" "$OUT/dex" "$OUT/generated"
# Only delete generated outputs inside this dedicated build directory.
find "$OUT/classes" "$OUT/dex" -type f -delete
python3 - <<'PY'
from pathlib import Path
import xml.etree.ElementTree as ET
ns='http://schemas.android.com/apk/res/android'
ET.register_namespace('android',ns)
p=ET.parse('app/src/main/AndroidManifest.xml')
p.getroot().set('package','cn.shiji.offline')
p.getroot().find('application').set('{'+ns+'}debuggable','true')
p.write('build/sdk-debug/AndroidManifest.xml',encoding='utf-8',xml_declaration=True)
PY
"$SDK_TOOLS/aapt2" compile --dir app/src/main/res -o "$OUT/resources.zip"
"$SDK_TOOLS/aapt2" link -o "$OUT/unsigned.apk" -I "$ANDROID_JAR" \
  --auto-add-overlay --manifest "$OUT/AndroidManifest.xml" --java "$OUT/generated" \
  --min-sdk-version 26 --target-sdk-version 35 --version-code 1 --version-name 1.0.0 \
  -A app/src/main/assets -R "$OUT/resources.zip"
"$JAVA_EXEC" --module jdk.compiler/com.sun.tools.javac.Main -encoding UTF-8 \
  -source 17 -target 17 -classpath "$ANDROID_JAR" -d "$OUT/classes" \
  app/src/main/java/cn/shiji/offline/*.java "$OUT/generated/cn/shiji/offline/R.java"
find "$OUT/classes" -name '*.class' > "$OUT/classes.args"
"$JAVA_EXEC" -cp "$SDK_TOOLS/lib/d8.jar" com.android.tools.r8.D8 \
  --debug --min-api 26 --lib "$ANDROID_JAR" --output "$OUT/dex" "@$OUT/classes.args"
python3 - <<'PY'
from pathlib import Path
import zipfile
with zipfile.ZipFile('build/sdk-debug/unsigned.apk','a',zipfile.ZIP_DEFLATED) as z:
    for p in sorted(Path('build/sdk-debug/dex').glob('*.dex')):
        z.write(p,p.name)
PY
"$SDK_TOOLS/zipalign" -f 4 "$OUT/unsigned.apk" "$OUT/aligned.apk"
KEY_FILE="$OUT/trial-debug.keystore"
if [ ! -f "$KEY_FILE" ]; then
  "$KEYTOOL_EXEC" -genkeypair -keystore "$KEY_FILE" -storepass android -keypass android \
    -alias androiddebugkey -keyalg RSA -keysize 2048 -validity 10000 \
    -dname "CN=Shiji Trial,OU=Development,O=Shiji,L=Local,ST=Local,C=CN" >/dev/null
fi
"$SDK_TOOLS/apksigner" sign --ks "$KEY_FILE" --ks-key-alias androiddebugkey \
  --ks-pass pass:android --key-pass pass:android --out "$OUT/shiji-offline-debug.apk" "$OUT/aligned.apk"
"$SDK_TOOLS/apksigner" verify --verbose "$OUT/shiji-offline-debug.apk"
echo "APK: $OUT/shiji-offline-debug.apk"

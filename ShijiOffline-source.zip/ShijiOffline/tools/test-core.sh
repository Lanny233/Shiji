#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
mkdir -p build/core-test
javac -encoding UTF-8 -d build/core-test app/src/main/java/cn/shiji/offline/WorkSession.java app/src/main/java/cn/shiji/offline/TimeMath.java app/src/main/java/cn/shiji/offline/HolidayRules.java tests/CoreTest.java
java -cp build/core-test CoreTest

import cn.shiji.offline.*;
import java.time.*;
import java.util.*;
import java.io.*;
import java.nio.charset.StandardCharsets;

public final class CoreTest {
    static void eq(Object actual,Object expected){if(!actual.equals(expected))throw new AssertionError("Expected "+expected+", got "+actual);}
    static long ts(String value){return OffsetDateTime.parse(value).toInstant().toEpochMilli();}
    static List<HolidayRules.Day> csv(String text)throws Exception{return HolidayRules.readCsv(new ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)));}
    public static void main(String[] args)throws Exception{
        WorkSession night=new WorkSession(1,ts("2026-09-21T23:00:00+08:00"),ts("2026-09-22T02:00:00+08:00"),"");
        List<WorkSession> rows=List.of(night,new WorkSession(2,ts("2026-09-22T09:00:00+08:00"),ts("2026-09-22T12:30:00+08:00"),""));
        eq(TimeMath.workMillis(rows,LocalDate.parse("2026-09-21")),3600000L);
        eq(TimeMath.workMillis(rows,LocalDate.parse("2026-09-22")),19800000L);
        eq(TimeMath.workMillis(rows,LocalDate.parse("2026-09-23")),0L);
        eq(TimeMath.workMillis(List.of(new WorkSession(3,night.start,null,"")),LocalDate.parse("2026-09-21")),0L);
        eq(TimeMath.monday(LocalDate.parse("2026-10-01")),LocalDate.parse("2026-09-28"));
        eq(TimeMath.hours(19800000),"5.5");eq(TimeMath.elapsed(3601000),"01:00:01");
        Map<LocalDate,HolidayRules.Day> days=new HashMap<>();
        try(InputStream in=new FileInputStream("app/src/main/assets/holidays-2026.csv")){
            for(HolidayRules.Day d:HolidayRules.readCsv(in))days.put(d.date,d);
        }
        eq(HolidayRules.automaticMillis(LocalDate.parse("2026-09-25"),days),28800000L);
        eq(HolidayRules.automaticMillis(LocalDate.parse("2026-10-03"),days),0L);
        eq(HolidayRules.automaticMillis(LocalDate.parse("2026-10-05"),days),0L);
        eq(HolidayRules.automaticMillis(LocalDate.parse("2026-09-20"),days),0L);
        eq(HolidayRules.automaticMillis(LocalDate.parse("2027-01-01"),days),0L);
        eq(csv("\uFEFFdate,type,name\n2027-01-01,LEGAL,元旦\n").size(),1);
        for(String bad:List.of("2026-02-30,LEGAL,错误","2026-01-01,WHAT,错误","2026-01-01,LEGAL,元旦\n2026-01-01,OFF,重复","# Empty")){
            try{csv(bad);throw new AssertionError("Invalid CSV accepted");}catch(IOException expected){}
        }
        System.out.println("PASS: midnight splitting, multiple sessions, active exclusion, cross-month week, hours, holiday/weekend/compensatory rules, CSV import validation.");
    }
}

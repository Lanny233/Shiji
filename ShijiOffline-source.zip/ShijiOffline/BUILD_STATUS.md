# 本次交付的验证状态

- 提供原生安卓测试 APK：ShijiOffline-debug.apk。
- 包名：cn.shiji.offline；版本：1.0.0；versionCode：1。
- 最低 Android 8.0 / API 26；target / compile SDK 35。
- 已使用 Android SDK 35、Build Tools 35.0.0 完成资源编译、Java 编译、DEX 转换、APK 打包、对齐和签名。
- `apksigner verify --verbose` 通过；APK v2、v3 签名有效。
- `zipalign -c 4` 通过。
- APK 清单检查：主 Activity 可启动；没有声明 INTERNET 或其他 uses-permission 权限。
- 纯 Java 工时/节假日测试通过：跨午夜、多段记录、进行中排除、跨月周、节假日/调休/周末规则、CSV 异常输入。
- SQLite 建表语句及约束检查通过：只允许一条进行中的记录、拒绝结束早于开始的时间。
- 未进行 Android 模拟器或安卓真机交互测试，不把编译成功等同于真机功能全量验证。

## 构建路径的说明

本环境的 Java 17 含 `jdk.compiler` 模块，但缺少完整 JDK 工具链启动程序，因此 Gradle 的 JAVA_COMPILER 能力检查未通过。本次实际生成 APK 用的是项目中的 `tools/build-sdk.sh`：直接调用真实的 Java 编译器模块、AAPT2、D8、zipalign 和 apksigner，并不是网页套壳或占位 APK。

Android Studio / Gradle 是推荐给用户的日常构建路径；它要求安装完整 JDK 17。该路径的构建配置已给出，但本环境未完成一次成功的 Gradle assembleDebug；上述 SDK 直接打包路径已成功运行。

提供的 APK 使用试用 debug 签名，不包含签名私钥。正式长期使用建议先在自己的电脑选择并保管签名密钥，再开始记录。

APK SHA-256：
`9bc7b01706b1d04ae5bfe0ffa15adf3c7af90faae964d1b4941cae5a79853216`

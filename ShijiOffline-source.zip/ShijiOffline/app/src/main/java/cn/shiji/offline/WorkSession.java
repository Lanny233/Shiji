package cn.shiji.offline;

/** One continuous work interval. A null end means clocked in. */
public final class WorkSession {
    public final long id, start;
    public final Long end;
    public final String note;
    public WorkSession(long id, long start, Long end, String note) {
        this.id=id; this.start=start; this.end=end; this.note=note;
    }
}

package cn.shiji.offline;

import android.content.*;
import android.database.Cursor;
import android.database.sqlite.*;
import java.io.*;
import java.time.LocalDate;
import java.util.*;

/** This is the only database access layer; call it on the activity's single worker thread. */
public final class WorkDb extends SQLiteOpenHelper {
    private final Context context;
    public WorkDb(Context c) { super(c.getApplicationContext(),"shiji.db",null,1);context=c.getApplicationContext(); }
    @Override public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE work_sessions(id INTEGER PRIMARY KEY AUTOINCREMENT,start_ms INTEGER NOT NULL,end_ms INTEGER,note TEXT NOT NULL DEFAULT '',active INTEGER UNIQUE,CHECK(end_ms IS NULL OR end_ms>start_ms),CHECK((end_ms IS NULL AND active=1) OR (end_ms IS NOT NULL AND active IS NULL)))");
        db.execSQL("CREATE INDEX sessions_start ON work_sessions(start_ms)");
        db.execSQL("CREATE TABLE day_adjustments(day TEXT PRIMARY KEY,bonus_ms INTEGER NOT NULL CHECK(bonus_ms>=0 AND bonus_ms<=86400000))");
        db.execSQL("CREATE TABLE holidays(day TEXT PRIMARY KEY,type TEXT NOT NULL,name TEXT NOT NULL)");
        db.execSQL("CREATE TABLE holiday_years(year INTEGER PRIMARY KEY)");
        try(InputStream input=context.getAssets().open("holidays-2026.csv")) {
            insertHolidays(db,HolidayRules.readCsv(input));
        }catch(IOException e){throw new IllegalStateException("初始化节假日数据失败",e);}
    }
    @Override public void onUpgrade(SQLiteDatabase db,int oldVersion,int newVersion) {
        // When adding a feature, add a non-destructive migration and increment DB version.
        throw new IllegalStateException("尚未定义从 "+oldVersion+" 到 "+newVersion+" 的数据库迁移");
    }
    public static final class Snapshot {
        public final List<WorkSession> sessions=new ArrayList<>();
        public final Map<LocalDate,Long> bonuses=new HashMap<>();
        public final Map<LocalDate,HolidayRules.Day> holidays=new HashMap<>();
        public final Set<Integer> holidayYears=new TreeSet<>();
        public WorkSession active(){for(WorkSession s:sessions)if(s.end==null)return s;return null;}
        public long bonus(LocalDate day){Long v=bonuses.get(day);return v!=null?v:HolidayRules.automaticMillis(day,holidays);}
        public long total(LocalDate day){return TimeMath.workMillis(sessions,day)+bonus(day);}
        public long range(LocalDate start,int days){long n=0;for(int i=0;i<days;i++)n+=total(start.plusDays(i));return n;}
    }
    public Snapshot snapshot() {
        SQLiteDatabase db=getReadableDatabase();Snapshot s=new Snapshot();
        try(Cursor c=db.rawQuery("SELECT id,start_ms,end_ms,note FROM work_sessions ORDER BY start_ms DESC",null)){
            while(c.moveToNext())s.sessions.add(new WorkSession(c.getLong(0),c.getLong(1),c.isNull(2)?null:c.getLong(2),c.getString(3)));
        }
        try(Cursor c=db.rawQuery("SELECT day,bonus_ms FROM day_adjustments",null)){
            while(c.moveToNext())s.bonuses.put(LocalDate.parse(c.getString(0)),c.getLong(1));
        }
        try(Cursor c=db.rawQuery("SELECT day,type,name FROM holidays",null)){
            while(c.moveToNext()){LocalDate d=LocalDate.parse(c.getString(0));s.holidays.put(d,new HolidayRules.Day(d,c.getString(1),c.getString(2)));}
        }
        try(Cursor c=db.rawQuery("SELECT year FROM holiday_years ORDER BY year",null)){
            while(c.moveToNext())s.holidayYears.add(c.getInt(0));
        }
        return s;
    }
    public void start(long now) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            if(overlaps(db,0,now,null))throw new IllegalArgumentException("已有正在计时的记录，或手机时间早于已有记录。请先检查记录和手机时间。");
            ContentValues v=new ContentValues();v.put("start_ms",now);v.put("active",1);v.put("note","");db.insertOrThrow("work_sessions",null,v);
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    public void stop(long id,long now) {
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            long start;
            try(Cursor c=db.rawQuery("SELECT start_ms FROM work_sessions WHERE id=? AND end_ms IS NULL",new String[]{String.valueOf(id)})){
                if(!c.moveToFirst())throw new IllegalArgumentException("这条记录已结束，请刷新后重试");start=c.getLong(0);
            }
            if(now<=start)throw new IllegalArgumentException("下班时间早于上班，请检查手机时间或编辑这条记录");
            ContentValues v=new ContentValues();v.put("end_ms",now);v.putNull("active");db.update("work_sessions",v,"id=?",new String[]{String.valueOf(id)});
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    private boolean overlaps(SQLiteDatabase db,long id,long start,Long end) {
        try(Cursor c=db.rawQuery("SELECT 1 FROM work_sessions WHERE id<>? AND start_ms<? AND (end_ms IS NULL OR end_ms>?) LIMIT 1",
                new String[]{String.valueOf(id),String.valueOf(end==null?Long.MAX_VALUE:end),String.valueOf(start)})){return c.moveToFirst();}
    }
    public void save(long id,long start,Long end,String note) {
        long now=System.currentTimeMillis();
        if(start<0||start>now||(end!=null&&(end<=start||end>now)))throw new IllegalArgumentException("下班须晚于上班；起止时间不能在未来");
        if(note.length()>200)throw new IllegalArgumentException("备注最多 200 字");
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{
            if(overlaps(db,id,start,end))throw new IllegalArgumentException("与另一段打卡时间重叠，请调整时间");
            ContentValues v=new ContentValues();v.put("start_ms",start);v.put("note",note.trim());
            if(end==null){v.putNull("end_ms");v.put("active",1);}else{v.put("end_ms",end);v.putNull("active");}
            if(id==0)db.insertOrThrow("work_sessions",null,v);
            else if(db.update("work_sessions",v,"id=?",new String[]{String.valueOf(id)})!=1)throw new IllegalArgumentException("记录不存在，请刷新");
            db.setTransactionSuccessful();
        }finally{db.endTransaction();}
    }
    public void delete(long id){getWritableDatabase().delete("work_sessions","id=?",new String[]{String.valueOf(id)});}
    public void setBonus(LocalDate day,Long millis){
        SQLiteDatabase db=getWritableDatabase();
        if(millis==null){db.delete("day_adjustments","day=?",new String[]{day.toString()});return;}
        if(millis<0||millis>86400000)throw new IllegalArgumentException("补时应在 0 至 24 小时之间");
        ContentValues v=new ContentValues();v.put("day",day.toString());v.put("bonus_ms",millis);
        db.insertWithOnConflict("day_adjustments",null,v,SQLiteDatabase.CONFLICT_REPLACE);
    }
    private void insertHolidays(SQLiteDatabase db,List<HolidayRules.Day> days){
        Set<Integer> years=new HashSet<>();for(HolidayRules.Day d:days)years.add(d.date.getYear());
        for(int year:years){
            db.delete("holidays","day>=? AND day<?",new String[]{LocalDate.of(year,1,1).toString(),LocalDate.of(year+1,1,1).toString()});
            ContentValues v=new ContentValues();v.put("year",year);db.insertWithOnConflict("holiday_years",null,v,SQLiteDatabase.CONFLICT_REPLACE);
        }
        for(HolidayRules.Day d:days){ContentValues v=new ContentValues();v.put("day",d.date.toString());v.put("type",d.type);v.put("name",d.name);db.insertOrThrow("holidays",null,v);}
    }
    public void importHolidays(List<HolidayRules.Day> days){
        SQLiteDatabase db=getWritableDatabase();db.beginTransaction();
        try{insertHolidays(db,days);db.setTransactionSuccessful();}finally{db.endTransaction();}
    }
}

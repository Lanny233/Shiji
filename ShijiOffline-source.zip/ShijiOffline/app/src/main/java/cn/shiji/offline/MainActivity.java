package cn.shiji.offline;

import android.app.*;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.text.InputFilter;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.io.*;
import java.math.BigDecimal;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.*;

/** Native Android UI. No WebView, web server, account, network permission or service. */
public final class MainActivity extends Activity {
    private static final int BLUE=0xff3454d1, INK=0xff1e2b43, MUTED=0xff6f7e95,
            BG=0xfff5f7fb, WHITE=Color.WHITE, BORDER=0xffe4e9f2, GREEN=0xff668142;
    private static final int IMPORT_HOLIDAYS=101;
    private final ExecutorService worker=Executors.newSingleThreadExecutor();
    private final Handler main=new Handler(Looper.getMainLooper());
    private WorkDb db;
    private WorkDb.Snapshot data;
    private LinearLayout root,content,nav;
    private TextView timeLabel,elapsedLabel;
    private Button punchButton;
    private boolean busy=false;
    private String error="";
    private int tab=0;
    private LocalDate selected=TimeMath.today(), lastToday=TimeMath.today();
    private YearMonth month=YearMonth.from(selected);
    private final Runnable ticker=new Runnable(){@Override public void run(){
        LocalDate today=TimeMath.today();
        if(!today.equals(lastToday)){lastToday=today;if(tab==0)render();}
        updateClock();main.postDelayed(this,1000);
    }};
    @Override public void onCreate(Bundle state){
        super.onCreate(state);
        if(state!=null){tab=state.getInt("tab");selected=LocalDate.parse(state.getString("selected",selected.toString()));month=YearMonth.parse(state.getString("month",month.toString()));}
        db=new WorkDb(this);
        root=column();root.setBackgroundColor(BG);root.setPadding(dp(16),0,dp(16),0);
        if(Build.VERSION.SDK_INT>=30){
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view,insets)->{
                android.graphics.Insets bars=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout());
                view.setPadding(dp(16)+bars.left,bars.top,dp(16)+bars.right,bars.bottom);return insets;
            });
        }
        setContentView(root);render();reload();
    }
    @Override protected void onResume(){super.onResume();main.removeCallbacks(ticker);main.post(ticker);if(data!=null&&!busy)reload();}
    @Override protected void onPause(){main.removeCallbacks(ticker);super.onPause();}
    @Override protected void onDestroy(){main.removeCallbacks(ticker);worker.execute(()->db.close());worker.shutdown();super.onDestroy();}
    @Override protected void onSaveInstanceState(Bundle out){out.putInt("tab",tab);out.putString("selected",selected.toString());out.putString("month",month.toString());super.onSaveInstanceState(out);}

    private interface Task {void run() throws Exception;}
    private void runTask(Task task,String success,Runnable after){
        if(busy)return;busy=true;render();
        worker.execute(()->{
            try{task.run();WorkDb.Snapshot snapshot=db.snapshot();main.post(()->{
                if(isDestroyed())return;data=snapshot;busy=false;error="";render();if(after!=null)after.run();if(!success.isEmpty())toast(success);
            });}catch(Exception e){main.post(()->{if(isDestroyed())return;busy=false;error=e.getMessage()==null?"操作失败，请重试":e.getMessage();render();toast(error);});}
        });
    }
    private void reload(){runTask(()->{},"",null);}
    private void render(){
        if(root==null)return;root.removeAllViews();timeLabel=null;elapsedLabel=null;punchButton=null;
        LinearLayout header=row();header.setGravity(Gravity.CENTER_VERTICAL);header.setPadding(0,dp(12),0,dp(12));
        header.addView(text("时记",25,INK,true),new LinearLayout.LayoutParams(0,dp(48),1));
        Button help=button("规则 / 导入",false,()->showInfo());header.addView(help);root.addView(header);
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setClipToPadding(false);
        content=column();content.setPadding(0,dp(4),0,dp(12));scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        if(!error.isEmpty()){TextView err=text(error,14,0xffad3746,false);err.setPadding(dp(12),dp(10),dp(12),dp(10));content.addView(err);content.addView(button("重新读取",false,this::reload));}
        if(data==null){content.addView(text(busy?"正在读取本地记录…":"暂无数据，请重试",17,MUTED,false));}
        else if(tab==0)renderPunch();else renderCalendar();
        nav=row();nav.setPadding(0,dp(8),0,dp(8));
        Button a=button("◷  打卡",tab==0,()->{tab=0;render();});Button b=button("▦  工时日历",tab==1,()->{tab=1;render();});
        LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(52),1);lp.setMargins(dp(3),0,dp(3),0);nav.addView(a,lp);nav.addView(b,new LinearLayout.LayoutParams(lp));root.addView(nav);
        updateClock();
    }
    private void renderPunch(){
        LocalDate today=TimeMath.today();WorkSession active=data.active();
        content.addView(text("离线记录 · 北京时间",14,MUTED,false));space(content,14);
        LinearLayout card=card();card.setBackground(round(0xff2942a5,22));
        TextView day=text(today.format(DateTimeFormatter.ofPattern("M月d日  EEEE",Locale.CHINA)),16,0xffe0e7ff,false);card.addView(day);
        timeLabel=text("",43,WHITE,true);timeLabel.setGravity(Gravity.CENTER);timeLabel.setPadding(0,dp(22),0,dp(4));card.addView(timeLabel);
        elapsedLabel=text("",15,0xffd6e0ff,false);elapsedLabel.setGravity(Gravity.CENTER);card.addView(elapsedLabel);space(card,22);
        punchButton=button(active==null?"上班打卡":"下班打卡",false,()->{
            long now=System.currentTimeMillis();
            if(active==null)runTask(()->db.start(now),"上班时间已保存",null);
            else runTask(()->db.stop(active.id,now),"本次工时 "+TimeMath.elapsed(now-active.start)+"，已保存",null);
        });
        punchButton.setTextSize(25);punchButton.setTextColor(active==null?BLUE:0xff35501c);punchButton.setBackground(round(active==null?WHITE:0xffdcefc0,28));
        card.addView(punchButton,new LinearLayout.LayoutParams(-1,dp(116)));space(card,16);
        TextView hint=text(active==null?"轻触开始，无需联网":"已保存上班时间，退出后也能继续",13,0xffd6e0ff,false);hint.setGravity(Gravity.CENTER);card.addView(hint);content.addView(card);space(content,16);
        LinearLayout stats=row();
        LinearLayout s1=miniStat("今日实际工时",TimeMath.hours(TimeMath.workMillis(data.sessions,today)));
        LinearLayout s2=miniStat("本周累计（含补时）",TimeMath.hours(data.range(TimeMath.monday(today),7)));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(0,0,dp(7),0);stats.addView(s1,p);
        p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(dp(7),0,0,0);stats.addView(s2,p);content.addView(stats);space(content,10);
        content.addView(text("进行中工时在下班后计入统计；周统计为周一至周日。",13,MUTED,false));
        if(!data.holidayYears.contains(today.getYear()))content.addView(text(today.getYear()+" 年节假日未收录，请导入本地节假日表或手动补时。",14,0xff9b6b22,false));
        space(content,18);renderDay(today);
    }
    private void updateClock(){
        if(timeLabel==null||data==null)return;long now=System.currentTimeMillis();timeLabel.setText(TimeMath.clock(now));
        WorkSession s=data.active();elapsedLabel.setText(s==null?"准备好了，就开始吧":"本次已工作 "+TimeMath.elapsed(now-s.start));
    }
    private LinearLayout miniStat(String name,String hours){LinearLayout v=card();v.addView(text(name,13,MUTED,false));v.addView(text(hours+" 小时",25,INK,true));return v;}

    private void renderCalendar(){
        LinearLayout heading=row();heading.setGravity(Gravity.CENTER_VERTICAL);
        heading.addView(button("‹",false,()->{month=month.minusMonths(1);render();}),new LinearLayout.LayoutParams(dp(48),dp(48)));
        Button title=button(month.getYear()+" 年 "+month.getMonthValue()+" 月",false,this::pickMonth);
        heading.addView(title,new LinearLayout.LayoutParams(0,dp(48),1));
        heading.addView(button("›",false,()->{month=month.plusMonths(1);render();}),new LinearLayout.LayoutParams(dp(48),dp(48)));content.addView(heading);
        LinearLayout summary=card();summary.addView(text("本月累计  "+TimeMath.hours(data.range(month.atDay(1),month.lengthOfMonth()))+" 小时",21,BLUE,true));
        summary.addView(button("回到今天",false,()->{selected=TimeMath.today();month=YearMonth.from(selected);render();}));content.addView(summary);space(content,12);
        if(!data.holidayYears.contains(month.getYear()))content.addView(text("该年度节假日尚未收录，不自动补时；可导入或手动调整。",14,0xff9b6b22,false));
        LinearLayout weekdays=row();for(String d:new String[]{"一","二","三","四","五","六","日"}){
            TextView t=text(d,14,MUTED,false);t.setGravity(Gravity.CENTER);weekdays.addView(t,new LinearLayout.LayoutParams(0,dp(35),1));
        }content.addView(weekdays);
        LocalDate first=TimeMath.monday(month.atDay(1)),last=month.atEndOfMonth();LocalDate today=TimeMath.today();
        for(LocalDate week=first;!week.isAfter(last);week=week.plusDays(7)){
            LinearLayout cells=row();
            for(int i=0;i<7;i++){
                LocalDate date=week.plusDays(i);boolean chosen=date.equals(selected),inMonth=YearMonth.from(date).equals(month);
                long millis=data.total(date);HolidayRules.Day h=data.holidays.get(date);
                LinearLayout cell=column();cell.setGravity(Gravity.CENTER);cell.setPadding(0,dp(5),0,dp(5));
                GradientDrawable back=round(chosen?BLUE:WHITE,11);if(date.equals(today)&&!chosen)back.setStroke(dp(1),BLUE);cell.setBackground(back);
                TextView num=text(String.valueOf(date.getDayOfMonth()),16,chosen?WHITE:(inMonth?INK:MUTED),true);num.setGravity(Gravity.CENTER);cell.addView(num);
                TextView hours=text(millis==0?"—":TimeMath.hours(millis)+"h",12,chosen?0xffe4eaff:MUTED,false);hours.setGravity(Gravity.CENTER);cell.addView(hours);
                String label=h==null?"":h.type.equals("LEGAL")?"节":h.type.equals("WORK")?"班":"调";
                TextView flag=text(label,11,chosen?0xffdeefbd:GREEN,false);flag.setGravity(Gravity.CENTER);cell.addView(flag);
                cell.setContentDescription(date+"，"+TimeMath.hours(millis)+" 小时，"+(h==null?"":h.name));
                cell.setClickable(true);cell.setFocusable(true);cell.setEnabled(!busy);cell.setOnClickListener(v->{selected=date;render();});
                LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);p.setMargins(dp(1),dp(2),dp(1),dp(2));cells.addView(cell,p);
            }
            content.addView(cells);
            TextView sum=text(TimeMath.shortDate(week)+" – "+TimeMath.shortDate(week.plusDays(6))+"     本周 "+TimeMath.hours(data.range(week,7))+" 小时",12,MUTED,false);
            sum.setPadding(dp(5),dp(5),dp(5),dp(9));content.addView(sum);
        }
        content.addView(text("节：法定节日   调：调休/补休   班：补班\n跨月周按完整 7 天统计；点击日期编辑。",12,MUTED,false));space(content,18);renderDay(selected);
    }
    private void pickMonth(){LocalDate base=month.atDay(1);DatePickerDialog d=new DatePickerDialog(this,(v,y,m,day)->{month=YearMonth.of(y,m+1);selected=LocalDate.of(y,m+1,day);render();},base.getYear(),base.getMonthValue()-1,1);d.show();}

    private void renderDay(LocalDate day){
        LinearLayout box=card();LinearLayout head=row();head.setGravity(Gravity.CENTER_VERTICAL);
        head.addView(text(day.format(DateTimeFormatter.ofPattern("M月d日"))+" · 记录",19,INK,true),new LinearLayout.LayoutParams(0,-2,1));
        head.addView(button("＋ 补记",false,()->editSession(null,day)));box.addView(head);
        box.addView(text("当日累计 "+TimeMath.hours(data.total(day))+" 小时",21,BLUE,true));
        long from=TimeMath.startOfDay(day),to=TimeMath.startOfDay(day.plusDays(1));boolean any=false;
        for(WorkSession s:data.sessions){
            if(s.start>=to||(s.end!=null&&s.end<=from)||(s.end==null&&System.currentTimeMillis()<from))continue;
            any=true;space(box,13);
            box.addView(text(TimeMath.display(s.start)+" → "+(s.end==null?"进行中":TimeMath.display(s.end)),15,INK,true));
            if(s.end!=null){long inDay=Math.max(0,Math.min(s.end,to)-Math.max(s.start,from));box.addView(text("本日 "+TimeMath.hours(inDay)+" 小时 · 本段 "+TimeMath.hours(s.end-s.start)+" 小时",13,MUTED,false));}
            if(!s.note.isEmpty())box.addView(text(s.note,14,MUTED,false));
            LinearLayout actions=row();actions.addView(button("编辑",false,()->editSession(s,day)),new LinearLayout.LayoutParams(0,dp(46),1));
            Button delete=button("删除",false,()->new AlertDialog.Builder(this).setTitle("删除这条记录？").setMessage("本段工时将从所有统计中移除。跨日记录会整段删除。")
                .setNegativeButton("取消",null).setPositiveButton("删除",(dialog,which)->runTask(()->db.delete(s.id),"已删除",null)).show());
            delete.setTextColor(0xffb84050);actions.addView(delete,new LinearLayout.LayoutParams(0,dp(46),1));box.addView(actions);
        }
        if(!any){space(box,16);box.addView(text("这一天还没有打卡记录，可点击补记。",14,MUTED,false));}
        space(box,14);HolidayRules.Day holiday=data.holidays.get(day);
        String kind=holiday==null?"当日补时":holiday.name;
        box.addView(text(kind+"  +"+TimeMath.hours(data.bonus(day))+" 小时",15,GREEN,true));
        box.addView(text(data.bonuses.containsKey(day)?"已手动调整补时":"工作日的法定节日本日自动 +8 小时",12,MUTED,false));
        box.addView(button("修改 / 删除补时",false,()->editBonus(day)));content.addView(box);
    }

    /** Android date/time pickers avoid error-prone free-form date parsing. */
    private void editSession(WorkSession session,LocalDate day){
        long now=System.currentTimeMillis();long from=TimeMath.startOfDay(day)+9*3600000L;
        long to=TimeMath.startOfDay(day)+18*3600000L;
        if(day.equals(TimeMath.today())){to=Math.min(to,now);from=Math.min(from,to-3600000L);}
        final long[] times={session==null?from:session.start,session==null?to:(session.end==null?now:session.end)};
        LinearLayout form=column();form.setPadding(dp(22),dp(8),dp(22),dp(8));
        form.addView(text("北京时间；跨午夜会自动分摊到两天。",14,MUTED,false));space(form,10);
        form.addView(text("上班时间",15,INK,true));Button start=button(TimeMath.display(times[0]),false,null);start.setEnabled(true);form.addView(start);
        form.addView(text("下班时间",15,INK,true));Button end=button(TimeMath.display(times[1]),false,null);end.setEnabled(true);form.addView(end);
        start.setOnClickListener(v->pickDateTime(times[0],t->{times[0]=t;start.setText(TimeMath.display(t));}));
        end.setOnClickListener(v->pickDateTime(times[1],t->{times[1]=t;end.setText(TimeMath.display(t));}));
        CheckBox ongoing=new CheckBox(this);ongoing.setText("仍在工作（暂不记录下班时间）");ongoing.setTextSize(14);ongoing.setChecked(session!=null&&session.end==null);form.addView(ongoing);
        end.setEnabled(!ongoing.isChecked());ongoing.setOnCheckedChangeListener((b,checked)->end.setEnabled(!checked));
        EditText note=new EditText(this);note.setHint("备注（选填）");note.setTextSize(16);note.setFilters(new InputFilter[]{new InputFilter.LengthFilter(200)});if(session!=null)note.setText(session.note);form.addView(note);
        TextView validation=text("",14,0xffb84050,false);form.addView(validation);
        ScrollView scroll=new ScrollView(this);scroll.addView(form);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(session==null?"补记工时":"编辑记录").setView(scroll).setNegativeButton("取消",null).setPositiveButton("保存",null).create();
        dialog.setOnShowListener(x->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            if(busy)return;long current=System.currentTimeMillis();Long finish=ongoing.isChecked()?null:times[1];
            if(times[0]<0||times[0]>current||(finish!=null&&(finish<=times[0]||finish>current))){validation.setText("下班须晚于上班，时间不能在未来。");return;}
            String text=note.getText().toString();runTask(()->db.save(session==null?0:session.id,times[0],finish,text),"记录已保存",dialog::dismiss);
        }));dialog.show();
    }
    private interface TimePicked {void picked(long time);}
    private void pickDateTime(long initial,TimePicked callback){
        ZonedDateTime z=Instant.ofEpochMilli(initial).atZone(TimeMath.ZONE);
        DatePickerDialog picker=new DatePickerDialog(this,(view,y,m,d)->new TimePickerDialog(this,(time,h,min)->{
            try{callback.picked(LocalDateTime.of(y,m+1,d,h,min).atZone(TimeMath.ZONE).toInstant().toEpochMilli());}
            catch(RuntimeException e){toast("时间无效，请重试");}
        },z.getHour(),z.getMinute(),true).show(),z.getYear(),z.getMonthValue()-1,z.getDayOfMonth());
        picker.getDatePicker().setMinDate(0);picker.show();
    }
    private void editBonus(LocalDate day){
        LinearLayout form=column();form.setPadding(dp(22),dp(8),dp(22),dp(8));
        form.addView(text("在实际打卡工时上加计；设为 0 即删除补时。",14,MUTED,false));
        EditText hours=new EditText(this);hours.setInputType(InputType.TYPE_CLASS_NUMBER|InputType.TYPE_NUMBER_FLAG_DECIMAL);hours.setText(TimeMath.hours(data.bonus(day)));hours.setSelectAllOnFocus(true);hours.setTextSize(20);form.addView(hours);
        TextView validation=text("",14,0xffb84050,false);form.addView(validation);
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle(day+" 补时（小时）").setView(form).setNegativeButton("取消",null).setNeutralButton("恢复自动",null).setPositiveButton("保存",null).create();
        dialog.setOnShowListener(x->{
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{if(busy)return;try{
                BigDecimal n=new BigDecimal(hours.getText().toString().trim());
                if(n.signum()<0||n.compareTo(BigDecimal.valueOf(24))>0)throw new IllegalArgumentException();
                long millis=n.multiply(BigDecimal.valueOf(3600000)).longValueExact();
                runTask(()->db.setBonus(day,millis),"补时已保存",dialog::dismiss);
            }catch(IllegalArgumentException|ArithmeticException e){validation.setText("请填写 0 至 24 的有效小时数，例如 7.5");}});
            dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(v->runTask(()->db.setBonus(day,null),"已恢复自动补时",dialog::dismiss));
        });dialog.show();
    }
    private void showInfo(){
        String years=data==null?"正在读取":data.holidayYears.toString();
        new AlertDialog.Builder(this).setTitle("时记 · 完全离线")
            .setMessage("• 数据保存在手机 SQLite 数据库，不需要账户或网络。\n\n• 按北京时间统计；工时=下班减上班，不扣午休。午休可分两次打卡。跨日自动分摊，进行中记录在结束后入账。\n\n• 仅周一至周五的法定节日本日 +8 小时；周末节日、调休、补休、补班不自动加。实际出勤与补时相加；未来节日也显示补时。\n\n• 已有节假日年份："+years+"。其他年份不猜测，可手动补时，或导入完整年度 CSV。导入会替换文件所含年度的节假日，不改打卡与手动补时。\n\n• 计时依据手机系统时间；修改系统时间会影响时长。卸载/清除应用数据会删除本地记录。")
            .setPositiveButton("知道了",null).setNeutralButton("导入节假日 CSV",(d,w)->{
                if(busy)return;Intent intent=new Intent(Intent.ACTION_OPEN_DOCUMENT);intent.addCategory(Intent.CATEGORY_OPENABLE);intent.setType("*/*");
                try{startActivityForResult(intent,IMPORT_HOLIDAYS);}catch(ActivityNotFoundException e){toast("手机未提供文件选择器");}
            }).show();
    }
    @Override protected void onActivityResult(int request,int result,Intent intent){
        super.onActivityResult(request,result,intent);if(request!=IMPORT_HOLIDAYS||result!=RESULT_OK||intent==null)return;Uri uri=intent.getData();if(uri==null)return;
        // The system file picker grants access to this URI only; no broad storage permission needed.
        runTask(()->{try(InputStream in=getContentResolver().openInputStream(uri)){
            if(in==null)throw new IOException("无法读取文件");
            byte[] buffer=new byte[4096];ByteArrayOutputStream bytes=new ByteArrayOutputStream();int n;
            while((n=in.read(buffer))!=-1){if(bytes.size()+n>256*1024)throw new IOException("节假日文件不能超过 256 KB");bytes.write(buffer,0,n);}
            db.importHolidays(HolidayRules.readCsv(new ByteArrayInputStream(bytes.toByteArray())));
        }},"节假日数据已导入",null);
    }
    private int dp(float n){return Math.round(n*getResources().getDisplayMetrics().density);}
    private LinearLayout column(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.VERTICAL);return v;}
    private LinearLayout row(){LinearLayout v=new LinearLayout(this);v.setOrientation(LinearLayout.HORIZONTAL);return v;}
    private TextView text(String value,int size,int color,boolean bold){TextView v=new TextView(this);v.setText(value);v.setTextSize(size);v.setTextColor(color);v.setGravity(Gravity.CENTER_VERTICAL);v.setFontFeatureSettings("tnum");if(bold)v.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return v;}
    private Button button(String value,boolean primary,Runnable action){Button v=new Button(this);v.setText(value);v.setAllCaps(false);v.setTextSize(15);v.setMinWidth(0);v.setMinimumWidth(0);v.setMinHeight(dp(48));v.setPadding(dp(10),dp(5),dp(10),dp(5));v.setTextColor(primary?WHITE:BLUE);v.setBackground(round(primary?BLUE:0xffedf1fc,12));v.setStateListAnimator(null);v.setEnabled(!busy);if(action!=null)v.setOnClickListener(x->action.run());return v;}
    private LinearLayout card(){LinearLayout v=column();v.setPadding(dp(16),dp(16),dp(16),dp(16));GradientDrawable b=round(WHITE,18);b.setStroke(dp(1),BORDER);v.setBackground(b);return v;}
    private GradientDrawable round(int color,int radius){GradientDrawable b=new GradientDrawable();b.setColor(color);b.setCornerRadius(dp(radius));return b;}
    private void space(LinearLayout parent,int height){View v=new View(this);parent.addView(v,new LinearLayout.LayoutParams(1,dp(height)));}
    private void toast(String value){Toast.makeText(this,value,Toast.LENGTH_LONG).show();}
}

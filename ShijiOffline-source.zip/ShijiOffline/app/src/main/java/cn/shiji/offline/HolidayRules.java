package cn.shiji.offline;

import java.io.*;
import java.nio.charset.StandardCharsets;
import java.time.LocalDate;
import java.util.*;

/** Holiday definitions are local data. LEGAL is the actual statutory day, not the whole vacation. */
public final class HolidayRules {
    public static final class Day {
        public final LocalDate date;
        public final String type, name;
        public Day(LocalDate date,String type,String name){this.date=date;this.type=type;this.name=name;}
    }
    public static List<Day> readCsv(InputStream input) throws IOException {
        List<Day> rows=new ArrayList<>(); Set<LocalDate> seen=new HashSet<>();
        BufferedReader reader=new BufferedReader(new InputStreamReader(input,StandardCharsets.UTF_8));
        String line; int n=0;
        while((line=reader.readLine())!=null){
            n++; line=line.replace("\uFEFF","").trim();
            if(line.isEmpty()||line.startsWith("#")||line.equals("date,type,name"))continue;
            if(n>3000)throw new IOException("节假日文件过大，请限制在 3000 行以内");
            String[] p=line.split(",",-1);
            try{
                if(p.length!=3)throw new IllegalArgumentException();
                LocalDate d=LocalDate.parse(p[0].trim()); String type=p[1].trim(),name=p[2].trim();
                if(!Arrays.asList("LEGAL","OFF","WORK").contains(type)||name.isEmpty()||name.length()>30||!seen.add(d))throw new IllegalArgumentException();
                rows.add(new Day(d,type,name));
            }catch(RuntimeException e){throw new IOException("CSV 第 "+n+" 行无效。格式：2026-01-01,LEGAL,元旦；日期不得重复。",e);}
        }
        if(rows.isEmpty())throw new IOException("节假日文件没有有效日期");
        return rows;
    }
    /** Only a statutory day falling Monday-Friday gets eight hours. */
    public static long automaticMillis(LocalDate date, Map<LocalDate,Day> holidays) {
        Day day=holidays.get(date);
        return day!=null&&day.type.equals("LEGAL")&&TimeMath.weekday(date)?8L*3600000:0;
    }
}

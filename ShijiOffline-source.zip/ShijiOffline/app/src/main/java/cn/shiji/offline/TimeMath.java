package cn.shiji.offline;

import java.time.*;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;
import java.util.*;

/** Pure Java arithmetic: can be tested without Android, SQLite or an emulator. */
public final class TimeMath {
    public static final ZoneId ZONE = ZoneId.of("Asia/Shanghai");
    private TimeMath() {}
    public static LocalDate date(long millis) { return Instant.ofEpochMilli(millis).atZone(ZONE).toLocalDate(); }
    public static long startOfDay(LocalDate date) { return date.atStartOfDay(ZONE).toInstant().toEpochMilli(); }
    public static LocalDate today() { return date(System.currentTimeMillis()); }
    public static LocalDate monday(LocalDate date) { return date.with(TemporalAdjusters.previousOrSame(DayOfWeek.MONDAY)); }
    public static boolean weekday(LocalDate d) { return d.getDayOfWeek().getValue() <= 5; }
    public static long workMillis(List<WorkSession> sessions, LocalDate day) {
        long from=startOfDay(day), to=startOfDay(day.plusDays(1)), result=0;
        for (WorkSession s:sessions) {
            if (s.end!=null) result+=Math.max(0,Math.min(s.end,to)-Math.max(s.start,from));
        }
        return result;
    }
    public static String hours(long millis) {
        return java.math.BigDecimal.valueOf(millis).divide(java.math.BigDecimal.valueOf(3600000),2,java.math.RoundingMode.HALF_UP).stripTrailingZeros().toPlainString();
    }
    public static String elapsed(long millis) {
        long seconds=Math.max(0,millis/1000);
        return String.format(Locale.ROOT,"%02d:%02d:%02d",seconds/3600,seconds/60%60,seconds%60);
    }
    public static String display(long millis) {
        return Instant.ofEpochMilli(millis).atZone(ZONE).format(DateTimeFormatter.ofPattern("MM-dd HH:mm",Locale.CHINA));
    }
    public static String clock(long millis) {
        return Instant.ofEpochMilli(millis).atZone(ZONE).format(DateTimeFormatter.ofPattern("HH:mm:ss",Locale.CHINA));
    }
    public static String shortDate(LocalDate d) { return d.format(DateTimeFormatter.ofPattern("MM/dd")); }
}
